package p1;

//Assignment : Convert this program into menu driven program
// HINT  : enum OPTIONS{EXIT,ADD,SUB,MUL,DIV};
// Hint : Switch case  , do while

public class Day9_1 
{

	public static void main(String[] args) {
		Test t=new Test();
		t.add();
		t.sub();
		t.mul();
		t.div();

	}

}
