package p1;


public class Day9_2 
{

	public static void main(String[] args) {
		Test t=new Test();
		t.add();
		t.sub();
		t.mul();
		t.div();
		

	}

}
