import java.util.ArrayList;

public class Day11_5
{

	public static void main(String[] args) 
	{
		ArrayList<Integer> list=new ArrayList<Integer>();
		list.add(10);
		list.add(4);
		list.add(5);
		
		for(int element:list)
			System.out.print("\t "+element);
		
	}
}



/*
public class Day11_5 {

	public static void main(String[] args) 
	{
		int[] arr=new int[5];
		arr[0]=10;
		arr[1]=20;
		arr[2]=30;
		arr[3]=40;
		arr[4]=50;
		
		for(int element:arr)
			System.out.print("\t "+element);

	}

}
*/


