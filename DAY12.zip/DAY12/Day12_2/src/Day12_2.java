import java.util.ArrayList;



/*
class Student
{
	int rollno;
	String name;
	int age;
	
	Student(int rollno,String name,int age)
	{
		this.rollno=rollno;
		this.name=name;
		this.age=age;
	}

	@Override
	public String toString() {
		return "Student [rollno=" + rollno + ", name=" + name + ", age=" + age + "]";
	}

	
}

public class Day12_2 {

	public static void main(String[] args) 
	{
		Student s1=new Student(1,"akshita",34);
		Student s2=new Student(2,"sparsh",35);
		Student s3=new Student(3,"monish",9);
		
		// Create ArrayList
		ArrayList<Student> a1=new ArrayList<Student>();
		a1.add(s1);
		a1.add(s2);
		a1.add(s3);
		
		//System.out.println(a1.toString());
		
		//for each Student 's'  inside array list 'a1'
		// print the each 's'
		
		//s = a1[0]   s = a1[1]   s=a1[2] 
		
		//for(Student s:a1)
			//System.out.println(s);
		
		//for(int i=0;i<a1.size();i++)
			//System.out.println(a1.get(i));
		
		for(int i=0;i<a1.size();i++)
			System.out.println(a1.get(i).rollno);
	}

}
*/