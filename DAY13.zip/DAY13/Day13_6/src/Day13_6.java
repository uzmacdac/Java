import java.util.ArrayList;
import java.util.Collections;

public class Day13_6 {

	public static void main(String[] args) 
	{
		ArrayList<Integer> a1=new ArrayList<Integer>();
		a1.add(14);
		a1.add(10);
		a1.add(15);
		a1.add(20);
		System.out.println("Before Sorting "+a1);
		Collections.sort(a1);
		System.out.println("After Sorting : "+a1);
		

	}

}
