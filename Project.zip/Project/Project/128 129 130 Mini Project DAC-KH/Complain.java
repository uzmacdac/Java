//package pack1 ;

import java.util.*;
 interface ComplainJuvenile
{
	public void theft();
	public void harrasments();
	public void kidnapping();
	public void suicide();
	public void abandonmentInfant();
	public void physicalHarrasment();
}
public class Complain implements ComplainJuvenile
{
	public PersonalDetail p1 = new PersonalDetail();
	
	@Override
	public void theft()
	{
		System.out.println("\n-----------------------------------------  ");
		System.out.println("Section 390 - theft or Robbery : ");
		System.out.println("-----------------------------------------  ");
		System.out.println("Imprisonment up to 3 or 4 years.");
	}
	@Override
	public void harrasments()
	{
		System.out.println("-----------------------------------------  ");
		System.out.println("Section 392 -  Harrasments : ");
		System.out.println("-----------------------------------------  ");
		System.out.println("Imprisonment up to 3 or 4 years.");
	}
	@Override
	public void kidnapping()
	{
		System.out.println("-----------------------------------------  ");
		System.out.println("Section 360- Kidnapping for exporting");
		System.out.println("-----------------------------------------  ");
		System.out.println("Section 363A- Kidnapping for begging");
		System.out.println("This section includes serious punishments for 10 years ");
	}
	
	@Override
	public void suicide()
	{
		System.out.println("-----------------------------------------  ");
		System.out.println("\nSection 305- Abetment of Suicide :  ");
		System.out.println("-----------------------------------------  ");
		System.out.println("If any individual who encourages children to perform suicide");
		System.out.println("Individual who is under eighteen-year age will get punishment of death "); 
		System.out.println("Imprisonment up to 10 years.");
	}
	@Override
	public void abandonmentInfant()
	{
		System.out.println("-----------------------------------------  ");		
		System.out.println("Section 317 - Abandoment of Infant :  ");
		System.out.println("-----------------------------------------  ");
		System.out.println("The offence of exposing a toddler under twelve years aged");
		System.out.println(" This Section shall be liable with imprisonment of up to 7 years/fine/both.");
	}
	@Override
	public void physicalHarrasment()
	{
		
		if(p1.age < 12)
		{
			System.out.println("-----------------------------------------  ");
			System.out.println("Section 376-AB : physicalHarrasment");
			System.out.println("-----------------------------------------  ");
			System.out.println("Rigorous imprisonment of not less than 20 years/life & fine or death");
			
		}
		else
		{	
			if(p1.age >= 16 )
			{
				System.out.println("-----------------------------------------  ");
				System.out.println("Section 376(3) : physicalHarrasment");
				System.out.println("-----------------------------------------  ");
				System.out.println("Rigorous imprisonment of not less than 20 years/life & fine or death");
			}
		}	
	}
	
}

