import java.util.*;
import java.util.Scanner;
class WomenRegistration
{
	int WomenRegistrationid; 
	String password;
	int temp;
	String temp1;
	int count=0;
	
	void m1()
	{
		System.out.println("=======================================================");
		
		System.out.println("WELCOME TO NATIONAL CRIME REPRORTING DEPARTMENT");
		
		System.out.println("=======================================================");
	}
	WomenRegistration()
	{
			
	}
	
	void id()
	{
		System.out.println("=======================================================");
		System.out.println("sign up");
		System.out.println("=======================================================");
		Scanner sc10 = new Scanner (System.in);
		System.out.println("Enter WomenRegistration Id");
		int WomenRegistrationid = sc10.nextInt();
		System.out.println("Enter Password");
		String password = sc10.next();
		
		 temp = WomenRegistrationid;
		 temp1 = password;
		System.out.println("=======================================================");
		System.out.println("sign in");
		System.out.println("=======================================================");
		do
		{			
		Scanner sc11 = new Scanner (System.in);
		System.out.println("Enter  Id");
		int temp = sc11.nextInt();
		System.out.println("Enter Password");
		String temp1 = sc11.next();
		if(temp == WomenRegistrationid && temp1.equals(password))
		{
		count++;
		}
		else
		{
			System.out.println("Something went Wrong please Re-Enter ID&Password");
		
		}
		}while(count==0);
		
	}
		
}

class Details extends WomenRegistration
{
	String Name;
	int age;
	String Gender;
	String Emailid;
	String city;
	long MobileNo;
	Date currentdate;
	String Address;
	void m1()
	{
		System.out.println("=======================================================");
		
		System.out.println("ENTER PERSONAL DETAILS");
		
		System.out.println("=======================================================");	
	}
	
	void m2()
	{
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter Your Name:-");
	String Name =sc.next();
	
	System.out.println("Enter Your age:-");
	try
		{
			int age = sc.nextInt();
			
		}catch(InputMismatchException e)
		{
			System.out.println("Please enter valid age .It should be of integer type");
			sc.nextLine();
			System.out.print("Enter age again  : ");
			age = sc.nextInt();
		}
	
	System.out.println("Enter Your Email id:-");
	Scanner sc13 = new Scanner(System.in);
	String Emailid = sc13.nextLine();
	System.out.println("Enter city Name:-");
	String city = sc.next();
	
	System.out.println("Enter Mobile Number ONLY 10 Digit:-");
	long mobileno = sc.nextLong();
	
	System.out.println("Current date:-"+new Date());
	System.out.println("Enter Incident City:-");
	String Incidentcity = sc.next();
	System.out.println();
	Scanner sc2 = new Scanner(System.in);
	System.out.println("Enter Address:-");
	String Address = sc2.nextLine();
	}
	Details()
	{
		
		
	}
Details(String Gender)
	{
		
		this.Gender = Gender;
		
	}
	
	public	String getGender()
	{
		return this.Gender;
	}
	
	public void setGender(String Gender)
	{
		this.Gender = Gender;
	}

	

	

}

public class CrimeReport
{
	public static void main(String [] args)
	{
		WomenRegistration r = new WomenRegistration();
		r.m1();
		r.id();
	
		Details  d = new Details();
		d.m1();
		d.m2();
		System.out.println("Gender:-"+"   "+d.getGender());
		section t1 = new section();
		t1.m5();
		t1.m2();
		
	}
}