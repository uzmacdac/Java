
class FIRDemo{
	public static void main(String... args){
	System.out.println("\n \n FOR CHILD DEPARTMENT COMPILE AND EXECUTE : Online_FIR ");
		
		
		System.out.println("\n \n FOR WOMEN DEPARTMENT COMPILE AND EXECUTE : CrimeReport ");	
		
		System.out.println("\n \n FOR SENIOR CITIZEN DEPARTMENT COMPILE AND EXECUTE : SeniorCitizenDemo ");
		
	}
}