// package pack1 ;

import java.text.SimpleDateFormat;    
import java.util.*;
//import java.util.Date;

 class Online_FIR
{
	public static void main(String args[])
	{
		Scanner scan = new Scanner(System.in);
		//Registration pd1 = new PersonalDetail();
		PersonalDetail pd1 = new PersonalDetail();
		pd1.acceptRecord();
		//System.out.println("Select Type Of Complain :\n1) Juvenile Crime\n2) Womens Crime\n3) Senior Citizens ");
		System.out.println();
		int choice = 1;
		
		switch(choice)
		{
			case 1 :
				System.out.println("Enter choice :\n0) Exit and Print Form \n1) Theft\n2) Harrasments\n3) Kidnapping\n4) Suicide");
				System.out.println("5) Abandonment of Infant\n6) Physical Harrasment\n");
				int crimeChoice;
				do
				{
					crimeChoice = scan.nextInt();
					System.out.print("Selected Option : "+crimeChoice +"\n");
					Complain c = new Complain();
					PersonalDetail pd = (PersonalDetail)pd1;
					switch(crimeChoice)
					{
						case 0 :
							System.out.println("\n------------------------------------------------");
								break ;
						case 1 :
							c.theft();
							
							pd.setListOfCrimeChoice("1) Theft");
							break ;
						case 2 :
							c.harrasments();
							pd.setListOfCrimeChoice("2) harrasments");
							break ;
						case 3 :
							c.kidnapping();
							pd.setListOfCrimeChoice("3) kidnapping");
							break ;
						case 4 :
							c.suicide();
							pd.setListOfCrimeChoice("4) suicide");
							break ;
						case 5 :
							c.abandonmentInfant();
							pd.setListOfCrimeChoice("5) abandonmentInfant");
							break ;
						case 6 :
							c.physicalHarrasment();
							pd.setListOfCrimeChoice("6) physicalHarrasment");
							break ;	
						default :
							System.out.println("You entered wrong choice");
					}
				}while(crimeChoice != 0);
				
				break;
			/* case 2 :System.out.println("Go to Women Department ");			
				break;
			case 3 : System.out.println("Go to Senior Citizen Department ");
				break; */
			default :
				System.out.println("You have entered wrong choice .Please select valid complain . ");
				break;
		}
			
			pd1.displayRecord();
		
	}

}
