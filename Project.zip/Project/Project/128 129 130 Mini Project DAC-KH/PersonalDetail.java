//package pack1 ;

import java.text.SimpleDateFormat;  
//import java.util.Date;  
import java.util.*;

 class Registration
{
	public Scanner s = new Scanner(System.in);
	public String registrationId ;
	public String password ;
	public String pwd ="";
	
	public Registration()
	{
	}
	public Registration(String registrationId , String password )
	{
		
		this.registrationId = registrationId ;
		this.password       = password ; 
	}
	public void m1()
	{
		System.out.println("\n=================================================");
		System.out.println("Welcome To Maharashtra Police Online FIR Portal");		
		System.out.println("=================================================");
		System.out.print("\nEnter User Id : ");
     	registrationId = s.next();
		System.out.print("\nEnter password : ");
		password = s.next();
		
		for(int i=0 ; i<password.length() ; i++)
		{
			pwd = pwd +"*";
		}
		System.out.println("\n------------------------------------------------");
		
	}
	public void m2()
	{
		System.out.println("\n------ :: Online F.I.R Registration Form :: ------");
		System.out.println("=================================================");
		System.out.println("Welcome To Maharashtra Police Online FIR Portal");		
		System.out.println("=================================================");
		System.out.println("Registration Id   : "+registrationId);
		System.out.println("Password          : "+pwd);
	}
	public void acceptRecord()
	{
		
	}
	public void displayRecord()
	{
	}
	public String getRegistrationId()
	{
		return registrationId ;
	}
	public String getPassword()
	{
		return password;
	}
	public String getPwd()
	{
		return pwd;
	}
	public void setRegistrationId()
	{
		this.registrationId = registrationId ;
		
	}
	public void setPassword()
	{
		this.password = password ;
		
	}
	
	
}


public class PersonalDetail extends Registration 
{
	public Scanner sc = new Scanner(System.in);
	public SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");  
    public Date date = new Date(); 
	//Registration r1 = new Registration();	
	//System.out.println(formatter.format(date)); 
	public String firstName;
	public String lastName ;
	public int age ;
	public int accusedAge ;
	public String accusedFirstName;
	public String accusedLastName ;
	public String sMob ;
	public String emailId;
	public String address ;
	public String gender ;
	public String accusedGender ;
	public String city ;
	public String incidentPlace ;
	
	public List<String>	listOfCrimeChoice = new ArrayList<String>();
	public PersonalDetail()
	{
		
	}
	public PersonalDetail(String firstName , String lastName ,String sMob ,
	String emailId ,String address,String gender,String city)
	{
		this.firstName = firstName ;
		this.lastName  = lastName ;
		this.sMob      = sMob  ;
		this.emailId   = emailId ;
		this.address   = address ;
		this.gender    = gender ; 
		this.city      = city ;
	}
	public void acceptRecord()
	{
		super.m1();
		System.out.println("-------------------------------------------");
		System.out.println("Fill Your Detail : ");
		System.out.println("-------------------------------------------");
		System.out.print("Enter last Name     : ");
		this.lastName = sc.next();
		System.out.print("\nEnter first Name 	: ");
		this.firstName = sc.next();
		System.out.print("Enter Age     : ");
		try
		{
			this.age = sc.nextInt();
			
		}catch(InputMismatchException e)
		{
			System.out.println("Please enter valid age .It should be of integer type");
			sc.nextLine();
			System.out.print("Enter age again  : ");
			age = sc.nextInt();
		}
		
		System.out.print("\nEnter 10 digit mobile number : ");
		try
		{
			sMob = sc.next(); 
		
			byte[] mobNo = sMob.getBytes();
			if(mobNo.length <10 || mobNo.length >10)
			{
				throw new ArrayIndexOutOfBoundsException();
			}
			
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Please enter valid Mobile Number .");
			System.out.print("\nEnter 10 digit mobile number : ");
			sMob = sc.next(); 

		}	
		catch(Exception e)
		{
			System.out.println("Exception : Please enter valid Mobile Number .");
		}
		
		System.out.print("\nEnter Email Id      : ");
		this.emailId = sc.next();
	
		System.out.print("\nEnter gender        : ");
		this.gender = sc.next();
		System.out.print("\nEnter City          : ");
		this.city = sc.next();
		System.out.print("\nEnter Place of Incident : ");
		sc.nextLine();
		incidentPlace = sc.nextLine();
		System.out.print("\nEnter address       : ");
		address = sc.nextLine();
		System.out.println("-------------------------------------------");
		System.out.println("Fill Accused Detail : ");
		System.out.println("-------------------------------------------");
		System.out.print("Enter Accused last Name : ");
		this.accusedLastName = sc.next();
		System.out.print("\nEnter Accused first Name: ");
		this.accusedFirstName = sc.next();
		System.out.print("\nEnter Accused age     : ");
		try
		{
			
			this.accusedAge = sc.nextInt();
			sc.nextLine();
		}catch(InputMismatchException e)
		{
			System.out.println("Please enter valid age .It should be of integer type");
			System.out.print("Enter Accused age     : ");
			sc.nextLine();
			this.accusedAge = sc.nextInt();
		}
		
	}
	public void displayRecord()
	{
		super.m2();
		System.out.println("-------------------------------------------");
		System.out.println("Complainant Detail : ");
		System.out.println("-------------------------------------------");
		System.out.println("Name              : "+this.lastName+" "+this.firstName);
		System.out.println("Age               : "+age);
		System.out.println("gender            : "+this.gender);
/*add*/	System.out.println("Date Of Complain  : "+formatter.format(date));
		System.out.println("Email Id          : "+emailId);
		System.out.println("Address           : "+this.address);
		System.out.println("Mobile Number     : "+this.sMob);
		System.out.println("Email Id          : "+this.emailId);
		System.out.println("Place Of Incident : "+this.incidentPlace);
		System.out.println("City              : "+this.city);
		//System.out.println("List Of Accusations : ");
		/*for(String x : listOfCrimeChoice)
		{
			System.out.println(""+x);
		}*/
		System.out.println("-------------------------------------------");
		System.out.println("Accused Detail : ");
		System.out.println("-------------------------------------------");
		System.out.println("Accused Name      : "+this.accusedLastName+" "+this.accusedFirstName);
		System.out.println("Accused age       : "+this.accusedAge);
		System.out.println("List Of Accusations : ");
		for(String x : listOfCrimeChoice)
		{
			System.out.println(""+x);
		}
		System.out.println();
		
		System.out.println("-------------------------------------------");
		System.out.println("Your Form submitted Successfully ");
		System.out.println("-------------------------------------------");
		
	}
	public void setName(String firstName , String lastName ,String sMob ,
	String emailId ,String address,String gender ,String city)
	{
		this.lastName  = lastName ;
		this.firstName = firstName ;
		this.sMob      = sMob ;
		this.emailId   = emailId ;
		this.address   = address ;
		this.gender    = gender ; 
		this.city      = city ;
	}
	public void getName()
	{
		System.out.println("Name : "+this.lastName+" "+this.firstName);
	}
	public String getAddress()
	{
		return this.address ;
	}
	public String getMobileNo()
	{
		return this.sMob ;
	}
public	String getEmailId()
	{
		return this.emailId ;
	}
public	List getListOfCrimeChoice()
	{
		return listOfCrimeChoice;
	}
public	void  setListOfCrimeChoice(String choice)
	{
		listOfCrimeChoice.add(choice);
	}
	
}


