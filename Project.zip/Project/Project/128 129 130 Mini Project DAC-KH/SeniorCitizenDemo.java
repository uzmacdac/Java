import java.util.Scanner;
interface SeniorCitizenReport{
	public int ageVerification();
	public void punishment(int x);
}

class SeniorCitizen implements SeniorCitizenReport {
	static int flag;
	String name ; 
	String address ;
	int age ;
	String TAccusedName ;
	int TAccussedAge;
	
	SeniorCitizen(){}
	SeniorCitizen(String name, int age, String address,String TAccusedName,int TAccussedAge){
	this.name = name ;
	this.age = age ;
	this.address = address ;
	this.TAccusedName = TAccusedName;
	this.TAccussedAge = TAccussedAge ;
	
	}
	@Override
	public int ageVerification(){
		
		System.out.println("\n \n \t \t  Senior Citizen Age Verification ");
		if(age>=60){
		System.out.println("Valid Senior Citizen Age  :"+age);
		flag=1;
		}else 
		System.out.println("Invalid Senior Citizen Age : \n");
		
		return flag;
	}

	void display(){
		System.out.println("Name of applicant : "+name+"\n"+"Age of applicant : "+age+"\n"+"Address of applicant : "+address);
	}
	@Override
	public void punishment(int ch){
	
	int choice = ch; 
	switch(choice){
			  case 1 :
					   System.out.println("------------------------------------------------------------------------------------------------");
					   System.out.println("\t Section 420 : ");
					   System.out.println("-------------------------------------------------------------------------------------------------");
				       System.out.println("\t Section 420 in the Indian Penal Code deals with Cheating and dishonestly inducing delivery of property");
					   System.out.println("PUNISHMENT : \nThe maximum punishment which can be awarded under this section is imprisonment for a term of 7 year and fine");
					   System.out.println("-------------------------------------------------------------------------------------------------");

					   break;
			  case 2 : 
					   System.out.println("--------------------------------------------------------------------------------------------------");
					   System.out.println("\t Maintenance and Welfare of Parents and Senior Citizens Act 2007");
					   System.out.println("--------------------------------------------------------------------------------------------------");
					   System.out.println("PUNISHMENT : \nIntentionally abuse their parents or abandon them may be sentenced to six months'fine of Rs 10,000 or both");
					   System.out.println("--------------------------------------------------------------------------------------------------");

					   break;
			  case 3 : 
			  		   System.out.println("--------------------------------------------------------------------------------------------------");
					   System.out.println("\t Section 390 : ");
					   System.out.println("--------------------------------------------------------------------------------------------------");
					   System.out.println("\t Section 390 in The Indian Penal Code Robbery.—In all robbery there is either theft or extortion");
			           System.out.println("PUNISHMENT : \nRigorous imprisonment for a term which may extend to ten years, and shall also be liable to fine");   
					   System.out.println("--------------------------------------------------------------------------------------------------");

					   break;
			  default : System.out.println("Enter correct choice :");
				   }
    }
}
class SeniorCitizenDemo extends SeniorCitizen {
	
	public static void main(String[] args){
	Scanner sc = new Scanner(System.in);
	
	System.out.println("\n=================================================================== \n ");
	System.out.println("\n \t THIS IS SENIOR CITIZEN CRIME REPORTING DEPARTMENT ");
	System.out.println("\n =================================================================== \n ");
	
	System.out.println("Enter Name :");
	String s1 = sc.nextLine();
	System.out.print("Enter Age of Applicant For Verification : ");
	int age1 = sc.nextInt();
	sc.nextLine();
	System.out.println("Enter Address :");
	String address1 = sc.nextLine();
	System.out.println("Enter Accussed Name : ");
	String s2 = sc.nextLine();
	System.out.println("Enter Accussed Age : ");
	int TAge = sc.nextInt();
	

	SeniorCitizen scobj = new SeniorCitizen(s1, age1, address1, s2,TAge);
	scobj.display();
	scobj.ageVerification();
	
	if(SeniorCitizen.flag==1){
	
	System.out.println("1) Fraud\n"+"2) DOMESTIC VIOLENCE BY DESCENDANTS AND ACQUIRING PROPERTIES OF PARENTS \n" +"3) ROBBERY");

	System.out.println("Enter choice of crime :");
	int ch = sc.nextInt();
	scobj.punishment(ch);
	}
	else System.out.println("Go to another Department ");
	}
}