import java.util.Scanner;
public class section extends Details
{
	{
		System.out.println("=======================================================");
		
		System.out.println("CHOOSE CRIME" );
		
		System.out.println("=======================================================");	
		
		System.out.println();
		
		System.out.println("0)Exit and Enter Accussed Name\n 1) ACID THROWING\n"+"2) DOMESTIC VIOLENCE\n"+"3) RAPE\n" +"4) HARRASHMENT\n"+ "5)CHAIN SNATCHING\n"+ "6) CYBER CRIME");
		
	}
	void m5()
	{
			int c;
			System.out.println("fill up your choice");
			Scanner sc4 = new Scanner(System.in);
		do
		{
			 c = sc4.nextInt();
		
	
	switch(c)
	{
	case 1: {
				System.out.println(" Section 326-(A)"+ "ACID THROWING");
				System.out.println("  The minimum punishment is 10 years' imprisonment.and 40,000Rs fine");
			}
			break;
	case 2: {
				System.out.println(" Section-(509)"+ "DOMESTIC VIOLENCE");
				System.out.println(" The minimum punishment is 5 years' imprisonment.and 15,000Rs fine");
			}
			break;
	case 3:{
				System.out.println(" Section-(375, 376, 376A,376B, 376C, 376D, 376D)"+ "RAPE");
				System.out.println(" The minimum punishment is Life' imprisonment.and 10,0000Rs fine");
		   }
		break;
	case 4:{
				System.out.println(" Section-354(A)"+ "HARRASHMENT");
				System.out.println(" The minimum punishment is 7 Years' imprisonment.and 10,000 Rs fine");
		   }
		   break;
	case 5:{
				System.out.println(" Section-379(A)"+ "CHAIN SNATCHING");
				System.out.println(" The minimum punishment is 2 Years' imprisonment.and 5,000 Rs fine");
		   }
		   break;
	case 6:{
				System.out.println(" Section-379(A)"+ "CYBER CRIME");
				System.out.println(" The minimum punishment is 3 Years' imprisonment.and 25,000 Rs fine");
			}
			break;
	case 0:{
				
			}
			break;
	default:{
				System.out.println("You are Selecting Wrong Choice");
				
			}
			break;
			
		}
		}while(c!=0);
	
	}
	void m2()
		{
			String accusedname;
			System.out.println("Add accused name");
			Scanner sc5 = new Scanner(System.in);
			String name = sc5.nextLine();	
			System.out.println();
			System.out.println();
		System.out.println("YOUR FORM SUBMITTED SUCCESSFULLY." );
		
		System.out.println("=======================================================");	
		}
}